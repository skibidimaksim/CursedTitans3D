package com.cursedstudios.cursedtitans;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.minecraft.world.item.equipment.ArmorMaterials;
import net.minecraft.world.item.equipment.ArmorType;

@Mod(CursedTitans.MODID)
public final class CursedTitans {
    public static final String MODID = "cursed_titans";
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);

    public static final DeferredItem<TitanArmorItem> CACTUS_HELMET = ITEMS.registerItem("cactus_helmet", p -> new TitanArmorItem(ArmorMaterials.NETHERITE, ArmorType.HELMET, p));
    public static final DeferredItem<TitanArmorItem> CACTUS_CHESTPLATE = ITEMS.registerItem("cactus_chestplate", p -> new TitanArmorItem(ArmorMaterials.NETHERITE, ArmorType.CHESTPLATE, p));
    public static final DeferredItem<TitanArmorItem> CACTUS_LEGGINGS = ITEMS.registerItem("cactus_leggings", p -> new TitanArmorItem(ArmorMaterials.NETHERITE, ArmorType.LEGGINGS, p));
    public static final DeferredItem<TitanArmorItem> CACTUS_BOOTS = ITEMS.registerItem("cactus_boots", p -> new TitanArmorItem(ArmorMaterials.NETHERITE, ArmorType.BOOTS, p));
    public static final DeferredItem<TitanArmorItem> VOID_HELMET = ITEMS.registerItem("void_helmet", p -> new TitanArmorItem(ArmorMaterials.NETHERITE, ArmorType.HELMET, p));
    public static final DeferredItem<TitanArmorItem> VOID_CHESTPLATE = ITEMS.registerItem("void_chestplate", p -> new TitanArmorItem(ArmorMaterials.NETHERITE, ArmorType.CHESTPLATE, p));
    public static final DeferredItem<TitanArmorItem> VOID_LEGGINGS = ITEMS.registerItem("void_leggings", p -> new TitanArmorItem(ArmorMaterials.NETHERITE, ArmorType.LEGGINGS, p));
    public static final DeferredItem<TitanArmorItem> VOID_BOOTS = ITEMS.registerItem("void_boots", p -> new TitanArmorItem(ArmorMaterials.NETHERITE, ArmorType.BOOTS, p));
    public static final DeferredItem<TitanArmorItem> SOLAR_HELMET = ITEMS.registerItem("solar_helmet", p -> new TitanArmorItem(ArmorMaterials.NETHERITE, ArmorType.HELMET, p));
    public static final DeferredItem<TitanArmorItem> SOLAR_CHESTPLATE = ITEMS.registerItem("solar_chestplate", p -> new TitanArmorItem(ArmorMaterials.NETHERITE, ArmorType.CHESTPLATE, p));
    public static final DeferredItem<TitanArmorItem> SOLAR_LEGGINGS = ITEMS.registerItem("solar_leggings", p -> new TitanArmorItem(ArmorMaterials.NETHERITE, ArmorType.LEGGINGS, p));
    public static final DeferredItem<TitanArmorItem> SOLAR_BOOTS = ITEMS.registerItem("solar_boots", p -> new TitanArmorItem(ArmorMaterials.NETHERITE, ArmorType.BOOTS, p));

    public CursedTitans(IEventBus modBus) {
        ITEMS.register(modBus);
    }
}
