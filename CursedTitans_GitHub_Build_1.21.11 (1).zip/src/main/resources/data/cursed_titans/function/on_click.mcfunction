execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{ct_id:"titan_phone"}] run dialog show @s cursed_titans:main
execute if score @s ct3_cd matches 1.. unless items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{ct_id:"titan_phone"}] run title @s actionbar {"text":"Способность перезаряжается...","color":"gray"}
execute if score @s ct3_cd matches 0 if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{ct_id:"thorn_scythe"}] run function cursed_titans:abilities/thorns
execute if score @s ct3_cd matches 0 if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{ct_id:"void_greatsword"}] run function cursed_titans:abilities/void
execute if score @s ct3_cd matches 0 if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{ct_id:"solar_blade"}] run function cursed_titans:abilities/solar
