playsound minecraft:block.amethyst_block.chime master @a[distance=..24] ~ ~ ~ 1 1
particle minecraft:composter ^ ^1 ^2 0.5 0.4 0.5 0.02 25 force
particle minecraft:happy_villager ^ ^1 ^4 0.7 0.5 0.7 0.07 25 force
effect give @s minecraft:resistance 4 0 true
execute positioned ^ ^1 ^3 as @e[type=!player,type=!item,type=!experience_orb,type=!armor_stand,distance=..3,limit=8,sort=nearest] run effect give @s minecraft:slowness 4 1 true
title @s actionbar {"text":"✦ Терновая волна","color":"aqua"}
scoreboard players set @s ct4_cd 100
