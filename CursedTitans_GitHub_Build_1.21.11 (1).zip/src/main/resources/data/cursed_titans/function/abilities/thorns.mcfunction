playsound minecraft:block.amethyst_block.chime master @a[distance=..20] ~ ~ ~ 0.95 0.7
particle minecraft:happy_villager ~ ~1.0 ~ 2.0 0.4 2.0 0.15 100 force
particle minecraft:composter ~ ~0.5 ~ 2.2 0.3 2.2 0.02 100 force
effect give @s minecraft:resistance 5 1 true
execute as @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:armor_stand,distance=1..5,limit=8,sort=nearest] run effect give @s minecraft:slowness 4 2 true
title @s actionbar {"text":"✦ THORN BURST · щит и шипы","color":"green"}
scoreboard players set @s ct3_cd 100
