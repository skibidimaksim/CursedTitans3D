playsound minecraft:block.beacon.power_select master @a[distance=..24] ~ ~ ~ 1 1
particle minecraft:witch ~ ~1 ~ 1.2 0.8 1.2 0.12 100 force
effect give @s minecraft:night_vision 25 0 true
effect give @s minecraft:slow_falling 10 0 true
title @s actionbar {"text":"✦ Завеса ночи","color":"aqua"}
scoreboard players set @s ct4_cd 200
