playsound minecraft:entity.enderman.teleport master @a[distance=..24] ~ ~ ~ 1 1
particle minecraft:reverse_portal ^ ^1 ^2 0.5 0.4 0.5 0.04 65 force
particle minecraft:witch ^ ^1 ^5 0.6 0.6 0.6 0.05 30 force
effect give @s minecraft:speed 5 1 true
execute positioned ^ ^1 ^4 as @e[type=!player,type=!item,type=!experience_orb,type=!armor_stand,distance=..2.8,limit=8,sort=nearest] run effect give @s minecraft:weakness 4 1 true
title @s actionbar {"text":"✦ Разлом Бездны","color":"aqua"}
scoreboard players set @s ct4_cd 140
