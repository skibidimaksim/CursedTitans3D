playsound minecraft:entity.blaze.shoot master @a[distance=..24] ~ ~ ~ 1 1
particle minecraft:flame ^ ^1 ^2 0.2 0.2 0.2 0.03 35 force
particle minecraft:end_rod ^ ^1 ^5 0.4 0.4 0.4 0.02 35 force
effect give @s minecraft:fire_resistance 6 0 true
execute positioned ^ ^1 ^4 as @e[type=!player,type=!item,type=!experience_orb,type=!armor_stand,distance=..2.7,limit=8,sort=nearest] run effect give @s minecraft:glowing 5 0 true
title @s actionbar {"text":"✦ Солнечная вспышка","color":"aqua"}
scoreboard players set @s ct4_cd 120
