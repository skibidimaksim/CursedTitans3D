playsound minecraft:block.amethyst_block.chime master @a[distance=..24] ~ ~ ~ 1 1
particle minecraft:happy_villager ~ ~1 ~ 1.6 0.8 1.6 0.10 80 force
effect give @s minecraft:regeneration 6 1 true
effect give @s minecraft:absorption 10 0 true
title @s actionbar {"text":"✦ Жизненный цветок","color":"aqua"}
scoreboard players set @s ct4_cd 160
