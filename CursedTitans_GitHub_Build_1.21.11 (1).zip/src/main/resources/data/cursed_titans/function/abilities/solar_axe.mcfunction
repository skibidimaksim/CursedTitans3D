playsound minecraft:item.trident.thunder master @a[distance=..24] ~ ~ ~ 1 1
particle minecraft:end_rod ~ ~2 ~ 1 1 1 0.1 80 force
effect give @s minecraft:strength 6 1 true
effect give @s minecraft:fire_resistance 7 0 true
title @s actionbar {"text":"✦ Гнев Рассвета","color":"aqua"}
scoreboard players set @s ct4_cd 160
