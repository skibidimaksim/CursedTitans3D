playsound minecraft:block.respawn_anchor.charge master @a[distance=..24] ~ ~ ~ 1 1
particle minecraft:reverse_portal ~ ~1 ~ 2.1 0.6 2.1 0.10 95 force
effect give @s minecraft:speed 7 1 true
execute as @e[type=!player,type=!item,type=!experience_orb,type=!armor_stand,distance=..5,limit=8,sort=nearest] run effect give @s minecraft:slowness 5 1 true
title @s actionbar {"text":"✦ Притяжение Бездны","color":"aqua"}
scoreboard players set @s ct4_cd 200
