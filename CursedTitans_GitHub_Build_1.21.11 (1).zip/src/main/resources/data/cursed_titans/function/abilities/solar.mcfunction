playsound minecraft:entity.blaze.shoot master @a[distance=..20] ~ ~ ~ 1 1.3
particle minecraft:flame ^ ^1 ^2 0.3 0.3 0.3 0.05 55 force
particle minecraft:flame ^ ^1 ^4 0.5 0.5 0.5 0.05 65 force
particle minecraft:flame ^ ^1 ^6 0.7 0.7 0.7 0.05 75 force
execute positioned ^ ^1 ^4 as @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:armor_stand,distance=..2.7,limit=8,sort=nearest] run effect give @s minecraft:glowing 6 0 true
execute positioned ^ ^1 ^6 as @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:armor_stand,distance=..2.7,limit=8,sort=nearest] run effect give @s minecraft:glowing 6 0 true
effect give @s minecraft:fire_resistance 8 0 true
title @s actionbar {"text":"✦ SOLAR BLAST · луч света","color":"gold"}
scoreboard players set @s ct3_cd 120
