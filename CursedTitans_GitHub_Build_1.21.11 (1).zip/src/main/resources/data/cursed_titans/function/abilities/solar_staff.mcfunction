playsound minecraft:block.beacon.activate master @a[distance=..24] ~ ~ ~ 1 1
particle minecraft:end_rod ~ ~2 ~ 1.4 1.0 1.4 0.1 120 force
effect give @s minecraft:absorption 12 1 true
effect give @s minecraft:fire_resistance 12 0 true
title @s actionbar {"text":"✦ Солнечный щит","color":"aqua"}
scoreboard players set @s ct4_cd 160
