particle minecraft:reverse_portal ~ ~1 ~ 0.6 1.0 0.6 0.06 60 force
playsound minecraft:entity.enderman.teleport master @a[distance=..18] ~ ~ ~ 1 0.75
effect give @s minecraft:resistance 3 1 true
effect give @s minecraft:slow_falling 4 0 true
execute anchored feet positioned ^ ^ ^3 if block ~ ~ ~ minecraft:air if block ~ ~1 ~ minecraft:air run tp @s ~ ~ ~
particle minecraft:reverse_portal ~ ~1 ~ 0.7 0.9 0.7 0.03 90 force
execute as @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:experience_orb,type=!minecraft:armor_stand,distance=1..4,limit=8,sort=nearest] run effect give @s minecraft:weakness 4 1 true
title @s actionbar {"text":"✦ VOID DASH · рывок бездны","color":"light_purple"}
scoreboard players set @s ct3_cd 140
