playsound minecraft:block.rooted_dirt.break master @a[distance=..24] ~ ~ ~ 1 1
particle minecraft:composter ~ ~1 ~ 2 0.5 2 0.09 85 force
effect give @s minecraft:strength 6 0 true
effect give @s minecraft:resistance 6 0 true
title @s actionbar {"text":"✦ Каменная крепость","color":"aqua"}
scoreboard players set @s ct4_cd 180
