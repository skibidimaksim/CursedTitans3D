give @s cursed_titans:void_helmet 1
give @s cursed_titans:void_chestplate 1
give @s cursed_titans:void_leggings 1
give @s cursed_titans:void_boots 1
title @s actionbar {"text":"Комплект Титан Бездны [GeckoLib 3D]","color":"gold"}
