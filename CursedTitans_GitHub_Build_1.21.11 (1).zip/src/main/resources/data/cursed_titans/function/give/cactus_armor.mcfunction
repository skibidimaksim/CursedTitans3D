give @s cursed_titans:cactus_helmet 1
give @s cursed_titans:cactus_chestplate 1
give @s cursed_titans:cactus_leggings 1
give @s cursed_titans:cactus_boots 1
title @s actionbar {"text":"Комплект Колючий титан [GeckoLib 3D]","color":"gold"}
