execute if score @s ct3_get matches 1 run function cursed_titans:give/cactus_armor
execute if score @s ct3_get matches 2 run function cursed_titans:give/void_armor
execute if score @s ct3_get matches 3 run function cursed_titans:give/solar_armor
execute if score @s ct3_get matches 4 run function cursed_titans:give/thorn_scythe
execute if score @s ct3_get matches 5 run function cursed_titans:give/void_greatsword
execute if score @s ct3_get matches 6 run function cursed_titans:give/solar_blade
execute if score @s ct3_get matches 7 run function cursed_titans:give/titan_phone
