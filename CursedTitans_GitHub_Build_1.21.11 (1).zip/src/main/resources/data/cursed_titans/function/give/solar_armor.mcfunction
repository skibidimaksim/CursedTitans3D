give @s cursed_titans:solar_helmet 1
give @s cursed_titans:solar_chestplate 1
give @s cursed_titans:solar_leggings 1
give @s cursed_titans:solar_boots 1
title @s actionbar {"text":"Комплект Солнечный титан [GeckoLib 3D]","color":"gold"}
