scoreboard players enable @a ct3_get
execute as @a unless score @s ct3_join matches 1 run function cursed_titans:on_join
scoreboard players remove @a[scores={ct3_cd=1..}] ct3_cd 1
execute as @a[scores={ct3_get=1..}] at @s run function cursed_titans:give/select
scoreboard players set @a[scores={ct3_get=1..}] ct3_get 0
execute as @a[scores={ct3_use=1..}] at @s run function cursed_titans:on_click
scoreboard players set @a[scores={ct3_use=1..}] ct3_use 0
# Half-second (2 Hz) updates for the full-armor visual auras.
scoreboard players add #auraTick ctfx_clock 1
execute if score #auraTick ctfx_clock matches 10.. run function cursed_titans:auras/run
execute if score #auraTick ctfx_clock matches 10.. run scoreboard players set #auraTick ctfx_clock 0
