scoreboard players set @s ct3_cd 0
function cursed_titans:give/titan_phone
scoreboard players set @s ct3_join 1
