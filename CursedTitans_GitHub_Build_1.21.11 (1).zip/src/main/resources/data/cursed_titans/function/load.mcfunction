scoreboard objectives add ct3_join dummy
scoreboard objectives add ct3_use minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add ct3_cd dummy
scoreboard objectives add ct3_get trigger
scoreboard objectives add ctfx_clock dummy
