package com.cursedstudios.cursedtitans;

import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorMaterials;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAssets;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(CursedTitans.MODID)
public final class CursedTitans {
    public static final String MODID = "cursed_titans";
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);

    /** Netherite stats, but with our own equipment asset (a blank layer) so the vanilla
     *  flat armor layer is never drawn on the player's skin - only the GeckoLib 3D model shows. */
    private static ArmorMaterial material(String set) {
        ArmorMaterial n = ArmorMaterials.NETHERITE;
        ResourceKey<net.minecraft.world.item.equipment.EquipmentAsset> key =
                ResourceKey.create(EquipmentAssets.ROOT_ID, Identifier.fromNamespaceAndPath(MODID, set));
        return new ArmorMaterial(n.durability(), n.defense(), n.enchantmentValue(), n.equipSound(),
                n.toughness(), n.knockbackResistance(), n.repairIngredient(), key);
    }

    private static final ArmorMaterial WARDEN = material("warden");
    private static final ArmorMaterial VOID = material("void");
    private static final ArmorMaterial SOLAR = material("solar");

    private static DeferredItem<TitanArmorItem> piece(String name, ArmorMaterial m, ArmorType t) {
        return ITEMS.registerItem(name, props -> new TitanArmorItem(m, t, props));
    }

    public static final DeferredItem<TitanArmorItem> WARDEN_HELMET = piece("warden_helmet", WARDEN, ArmorType.HELMET);
    public static final DeferredItem<TitanArmorItem> WARDEN_CHESTPLATE = piece("warden_chestplate", WARDEN, ArmorType.CHESTPLATE);
    public static final DeferredItem<TitanArmorItem> WARDEN_LEGGINGS = piece("warden_leggings", WARDEN, ArmorType.LEGGINGS);
    public static final DeferredItem<TitanArmorItem> WARDEN_BOOTS = piece("warden_boots", WARDEN, ArmorType.BOOTS);
    public static final DeferredItem<TitanArmorItem> VOID_HELMET = piece("void_helmet", VOID, ArmorType.HELMET);
    public static final DeferredItem<TitanArmorItem> VOID_CHESTPLATE = piece("void_chestplate", VOID, ArmorType.CHESTPLATE);
    public static final DeferredItem<TitanArmorItem> VOID_LEGGINGS = piece("void_leggings", VOID, ArmorType.LEGGINGS);
    public static final DeferredItem<TitanArmorItem> VOID_BOOTS = piece("void_boots", VOID, ArmorType.BOOTS);
    public static final DeferredItem<TitanArmorItem> SOLAR_HELMET = piece("solar_helmet", SOLAR, ArmorType.HELMET);
    public static final DeferredItem<TitanArmorItem> SOLAR_CHESTPLATE = piece("solar_chestplate", SOLAR, ArmorType.CHESTPLATE);
    public static final DeferredItem<TitanArmorItem> SOLAR_LEGGINGS = piece("solar_leggings", SOLAR, ArmorType.LEGGINGS);
    public static final DeferredItem<TitanArmorItem> SOLAR_BOOTS = piece("solar_boots", SOLAR, ArmorType.BOOTS);

    public CursedTitans(IEventBus modBus) {
        ITEMS.register(modBus);
    }
}
