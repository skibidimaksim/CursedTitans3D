damage @s 7 minecraft:magic by @p[tag=ct_caster]
effect give @s minecraft:weakness 4 1
tag @s add ct_hit
