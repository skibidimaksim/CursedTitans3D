execute if score @s ct3_cd matches 1.. run return run function cursed_titans:cooldown_msg
tag @s add ct_caster
playsound minecraft:item.trident.thunder master @a[distance=..24] ~ ~ ~ 1 1
playsound minecraft:entity.generic.explode master @a[distance=..24] ~ ~ ~ 0.8 1.2
particle minecraft:end_rod ~ ~1 ~ 1.5 1 1.5 0.15 80 force
particle minecraft:flame ~ ~0.3 ~ 2.5 0.3 2.5 0.1 90 force
particle minecraft:explosion ~ ~1 ~ 1.5 0.5 1.5 0 6 force
effect give @s minecraft:strength 6 1 true
effect give @s minecraft:fire_resistance 7 0 true
execute as @e[type=#cursed_titans:targets,tag=!ct_caster,distance=..4.5] run function cursed_titans:fx/solar_blast
tag @s remove ct_caster
title @s actionbar [{"text":"✦ ","color":"gold"},{"translate":"ct.ability.solar_axe","fallback":"Dawn Wrath","color":"gold"}]
scoreboard players set @s ct3_cd 160
