execute if score @s ct3_cd matches 1.. run return run function cursed_titans:cooldown_msg
tag @s add ct_caster
playsound minecraft:entity.warden.attack_impact master @a[distance=..24] ~ ~ ~ 1.2 0.8
playsound minecraft:block.sculk_shrieker.shriek master @a[distance=..24] ~ ~ ~ 0.8 1
particle minecraft:sculk_soul ~ ~0.3 ~ 3 0.3 3 0.05 80 force
particle minecraft:explosion ~ ~0.5 ~ 2 0.3 2 0 6 force
effect give @s minecraft:strength 6 0 true
effect give @s minecraft:resistance 6 1 true
execute as @e[type=#cursed_titans:targets,tag=!ct_caster,distance=..5] run function cursed_titans:fx/warden_quake
tag @s remove ct_caster
title @s actionbar [{"text":"✦ ","color":"dark_aqua"},{"translate":"ct.ability.warden_axe","fallback":"Sculk Quake","color":"dark_aqua"}]
scoreboard players set @s ct3_cd 180
