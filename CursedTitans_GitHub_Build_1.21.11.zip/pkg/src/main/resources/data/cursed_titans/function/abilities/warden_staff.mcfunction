execute if score @s ct3_cd matches 1.. run return run function cursed_titans:cooldown_msg
tag @s add ct_caster
playsound minecraft:entity.warden.heartbeat master @a[distance=..24] ~ ~ ~ 1.2 0.8
playsound minecraft:entity.warden.listening master @a[distance=..24] ~ ~ ~ 1 1
particle minecraft:sculk_soul ~ ~1 ~ 1.6 1 1.6 0.08 90 force
effect give @a[distance=..8] minecraft:resistance 8 1
effect give @a[distance=..8] minecraft:regeneration 5 0
execute as @e[type=#cursed_titans:targets,tag=!ct_caster,distance=..16] run function cursed_titans:fx/warden_mark
tag @s remove ct_caster
title @s actionbar [{"text":"✦ ","color":"dark_aqua"},{"translate":"ct.ability.warden_staff","fallback":"Soul Sense","color":"dark_aqua"}]
scoreboard players set @s ct3_cd 200
