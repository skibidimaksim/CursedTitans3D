damage @s 8 minecraft:magic by @p[tag=ct_caster]
effect give @s minecraft:slowness 4 2
effect give @s minecraft:weakness 4 0
