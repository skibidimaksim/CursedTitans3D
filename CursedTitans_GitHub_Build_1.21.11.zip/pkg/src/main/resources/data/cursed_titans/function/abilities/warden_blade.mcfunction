execute if score @s ct3_cd matches 1.. run return run function cursed_titans:cooldown_msg
tag @s add ct_caster
playsound minecraft:entity.warden.sonic_charge master @a[distance=..24] ~ ~ ~ 1 1
playsound minecraft:entity.warden.sonic_boom master @a[distance=..32] ~ ~ ~ 1.2 1
scoreboard players set #steps ct3_tmp 14
execute anchored eyes positioned ^ ^-0.2 ^0.8 run function cursed_titans:fx/sonic_step
tag @e[tag=ct_hit] remove ct_hit
tag @s remove ct_caster
title @s actionbar [{"text":"✦ ","color":"dark_aqua"},{"translate":"ct.ability.warden_blade","fallback":"Sonic Boom","color":"dark_aqua"}]
scoreboard players set @s ct3_cd 160
