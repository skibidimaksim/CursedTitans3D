damage @s 6 minecraft:magic by @p[tag=ct_caster]
data merge entity @s {Fire:80s}
effect give @s minecraft:glowing 5 0
