damage @s 10 minecraft:magic by @p[tag=ct_caster]
effect give @s minecraft:slowness 3 1
effect give @s minecraft:weakness 4 0
tag @s add ct_hit
