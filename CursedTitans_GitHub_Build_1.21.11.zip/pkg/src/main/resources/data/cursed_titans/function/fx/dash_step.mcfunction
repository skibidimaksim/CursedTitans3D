# context: as caster, rotated ~ 0 (horizontal). Moves 1 block, stops at walls.
execute unless block ^ ^ ^1 #cursed_titans:passable run return 0
execute unless block ^ ^1 ^1 #cursed_titans:passable run return 0
tp @s ^ ^ ^1
scoreboard players remove #steps ct3_tmp 1
execute at @s run particle minecraft:reverse_portal ~ ~1 ~ 0.3 0.5 0.3 0.05 12 force
execute if score #dmg ct3_tmp matches 1 at @s as @e[type=#cursed_titans:targets,tag=!ct_caster,tag=!ct_hit,distance=..2.5] run function cursed_titans:fx/void_hit
execute if score #steps ct3_tmp matches 1.. at @s rotated ~ 0 run function cursed_titans:fx/dash_step
