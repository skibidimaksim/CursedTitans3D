effect give @s minecraft:glowing 8 0
effect give @s minecraft:weakness 4 0
