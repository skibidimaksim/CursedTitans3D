damage @s 8 minecraft:magic by @p[tag=ct_caster]
data merge entity @s {Fire:100s}
effect give @s minecraft:glowing 6 0
tag @s add ct_hit
