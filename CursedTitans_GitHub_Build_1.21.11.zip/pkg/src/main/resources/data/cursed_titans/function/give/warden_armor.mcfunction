give @s cursed_titans:warden_helmet 1
give @s cursed_titans:warden_chestplate 1
give @s cursed_titans:warden_leggings 1
give @s cursed_titans:warden_boots 1
title @s actionbar {"translate":"ct.got_armor","fallback":"Set received: %s","with":[{"translate":"ct.set.warden.name","fallback":"Warden Titan"}],"color":"dark_aqua"}
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 0.55 1.2
