execute if score @s ct3_get matches 7 run return run function cursed_titans:give/titan_phone
execute if score #free_menu ct3_cfg matches 0 unless entity @s[gamemode=creative] run return run tellraw @s {"translate":"ct.menu_locked","fallback":"Titan items are creative-only on this server.","color":"red"}
execute if score @s ct3_get matches 1 run function cursed_titans:give/warden_armor
execute if score @s ct3_get matches 2 run function cursed_titans:give/void_armor
execute if score @s ct3_get matches 3 run function cursed_titans:give/solar_armor
execute if score @s ct3_get matches 4 run function cursed_titans:give/warden_blade
execute if score @s ct3_get matches 5 run function cursed_titans:give/void_blade
execute if score @s ct3_get matches 6 run function cursed_titans:give/solar_blade
execute if score @s ct3_get matches 8 run function cursed_titans:give/warden_axe
execute if score @s ct3_get matches 9 run function cursed_titans:give/void_axe
execute if score @s ct3_get matches 10 run function cursed_titans:give/solar_axe
execute if score @s ct3_get matches 11 run function cursed_titans:give/warden_staff
execute if score @s ct3_get matches 12 run function cursed_titans:give/void_staff
execute if score @s ct3_get matches 13 run function cursed_titans:give/solar_staff
