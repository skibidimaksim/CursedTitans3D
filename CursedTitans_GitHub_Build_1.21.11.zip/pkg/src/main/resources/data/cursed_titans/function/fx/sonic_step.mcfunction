# context: positioned at the current beam point, rotated along the aim.
execute unless block ~ ~ ~ #cursed_titans:passable run return 0
particle minecraft:sculk_soul ~ ~ ~ 0.08 0.08 0.08 0.01 2 force
scoreboard players operation #p ct3_tmp = #steps ct3_tmp
scoreboard players operation #p ct3_tmp %= #3 ct3_const
execute if score #p ct3_tmp matches 0 run particle minecraft:sonic_boom ~ ~ ~ 0 0 0 0 1 force
execute as @e[type=#cursed_titans:targets,tag=!ct_caster,tag=!ct_hit,distance=..2.2] run function cursed_titans:fx/sonic_hit
scoreboard players remove #steps ct3_tmp 1
execute if score #steps ct3_tmp matches 1.. positioned ^ ^ ^1 run function cursed_titans:fx/sonic_step
