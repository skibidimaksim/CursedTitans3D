execute if score @s ct3_cd matches 1.. run return run function cursed_titans:cooldown_msg
tag @s add ct_caster
playsound minecraft:entity.enderman.teleport master @a[distance=..24] ~ ~ ~ 1 0.9
particle minecraft:witch ~ ~1 ~ 1.2 0.8 1.2 0.12 100 force
scoreboard players set #steps ct3_tmp 8
scoreboard players set #dmg ct3_tmp 0
execute rotated ~ 0 run function cursed_titans:fx/dash_step
execute at @s run particle minecraft:witch ~ ~1 ~ 1.2 0.8 1.2 0.12 100 force
execute at @s run playsound minecraft:block.beacon.power_select master @a[distance=..24] ~ ~ ~ 1 1
effect give @s minecraft:night_vision 25 0 true
effect give @s minecraft:slow_falling 6 0 true
tag @s remove ct_caster
title @s actionbar [{"text":"✦ ","color":"light_purple"},{"translate":"ct.ability.void_staff","fallback":"Veil of Night","color":"light_purple"}]
scoreboard players set @s ct3_cd 200
