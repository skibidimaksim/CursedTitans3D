scoreboard objectives add ct3_join dummy
scoreboard objectives add ct3_use minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add ct3_cd dummy
scoreboard objectives add ct3_get trigger
scoreboard objectives add ctfx_clock dummy
scoreboard objectives add ct3_tmp dummy
scoreboard objectives add ct3_const dummy
scoreboard objectives add ct3_cfg dummy
scoreboard players set #20 ct3_const 20
scoreboard players set #5 ct3_const 5
scoreboard players set #3 ct3_const 3
execute unless score #free_menu ct3_cfg matches 0..1 run scoreboard players set #free_menu ct3_cfg 1
