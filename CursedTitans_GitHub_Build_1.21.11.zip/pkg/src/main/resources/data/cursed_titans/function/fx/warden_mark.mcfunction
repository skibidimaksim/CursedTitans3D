effect give @s minecraft:glowing 10 0
effect give @s minecraft:weakness 5 0
effect give @s minecraft:slowness 3 0
