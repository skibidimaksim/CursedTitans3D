# context: as victim, at victim. Pulls 2 blocks toward the caster if the path is clear.
damage @s 5 minecraft:magic by @p[tag=ct_caster]
effect give @s minecraft:slowness 5 1
execute unless entity @p[tag=ct_caster,distance=..3] facing entity @p[tag=ct_caster] feet if block ^ ^ ^2 #cursed_titans:passable if block ^ ^1 ^2 #cursed_titans:passable run tp @s ^ ^ ^2
