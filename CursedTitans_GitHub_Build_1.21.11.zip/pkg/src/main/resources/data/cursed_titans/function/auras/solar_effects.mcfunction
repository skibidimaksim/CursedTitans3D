effect give @s minecraft:fire_resistance 3 0 true
execute if predicate cursed_titans:daylight run effect give @s minecraft:regeneration 3 0 true
