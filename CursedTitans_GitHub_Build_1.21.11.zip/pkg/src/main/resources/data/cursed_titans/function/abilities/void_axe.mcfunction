execute if score @s ct3_cd matches 1.. run return run function cursed_titans:cooldown_msg
tag @s add ct_caster
playsound minecraft:block.respawn_anchor.charge master @a[distance=..24] ~ ~ ~ 1 1
particle minecraft:reverse_portal ~ ~1 ~ 2.1 0.6 2.1 0.10 95 force
effect give @s minecraft:speed 7 1 true
execute as @e[type=#cursed_titans:targets,tag=!ct_caster,distance=..8] at @s run function cursed_titans:fx/void_pull
tag @s remove ct_caster
title @s actionbar [{"text":"✦ ","color":"light_purple"},{"translate":"ct.ability.void_axe","fallback":"Void Pull","color":"light_purple"}]
scoreboard players set @s ct3_cd 200
