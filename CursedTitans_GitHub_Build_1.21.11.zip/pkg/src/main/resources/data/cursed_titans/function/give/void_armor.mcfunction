give @s cursed_titans:void_helmet 1
give @s cursed_titans:void_chestplate 1
give @s cursed_titans:void_leggings 1
give @s cursed_titans:void_boots 1
title @s actionbar {"translate":"ct.got_armor","fallback":"Set received: %s","with":[{"translate":"ct.set.void.name","fallback":"Void Titan"}],"color":"light_purple"}
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 0.55 1.2
