execute if score @s ct3_cd matches 1.. run return run function cursed_titans:cooldown_msg
tag @s add ct_caster
playsound minecraft:block.beacon.activate master @a[distance=..24] ~ ~ ~ 1 1
particle minecraft:end_rod ~ ~2 ~ 1.4 1.0 1.4 0.1 120 force
particle minecraft:flame ~ ~0.3 ~ 2 0.2 2 0.05 40 force
effect give @a[distance=..6] minecraft:absorption 12 1
effect give @a[distance=..6] minecraft:fire_resistance 12 0 true
execute as @e[type=#cursed_titans:targets,tag=!ct_caster,distance=..6] run function cursed_titans:fx/solar_mark
tag @s remove ct_caster
title @s actionbar [{"text":"✦ ","color":"gold"},{"translate":"ct.ability.solar_staff","fallback":"Solar Shield","color":"gold"}]
scoreboard players set @s ct3_cd 160
