give @s cursed_titans:solar_helmet 1
give @s cursed_titans:solar_chestplate 1
give @s cursed_titans:solar_leggings 1
give @s cursed_titans:solar_boots 1
title @s actionbar {"translate":"ct.got_armor","fallback":"Set received: %s","with":[{"translate":"ct.set.solar.name","fallback":"Sun Titan"}],"color":"gold"}
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 0.55 1.2
