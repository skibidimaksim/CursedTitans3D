effect give @s minecraft:night_vision 13 0 true
effect give @s minecraft:speed 3 0 true
