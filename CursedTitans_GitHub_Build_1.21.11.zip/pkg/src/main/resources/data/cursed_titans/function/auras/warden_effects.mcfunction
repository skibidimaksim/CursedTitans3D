effect give @s minecraft:resistance 3 0 true
execute as @e[type=#cursed_titans:targets,tag=!ct_caster,distance=..12] run effect give @s minecraft:glowing 2 0 true
