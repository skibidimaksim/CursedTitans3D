scoreboard players operation #s ct3_tmp = @s ct3_cd
scoreboard players add #s ct3_tmp 19
scoreboard players operation #s ct3_tmp /= #20 ct3_const
title @s actionbar {"translate":"ct.cooldown","fallback":"Recharging... %ss","with":[{"score":{"name":"#s","objective":"ct3_tmp"}}],"color":"gray"}
playsound minecraft:block.dispenser.fail master @s ~ ~ ~ 0.4 1.6
