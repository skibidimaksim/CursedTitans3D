scoreboard players set @s ct3_cd 0
function cursed_titans:give/titan_phone
tellraw @s {"translate":"ct.welcome","fallback":"You received the Titanophone. Right-click it to open the Titans menu.","color":"aqua"}
scoreboard players set @s ct3_join 1
