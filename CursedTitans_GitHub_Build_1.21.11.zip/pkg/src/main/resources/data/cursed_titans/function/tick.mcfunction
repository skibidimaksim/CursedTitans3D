scoreboard players enable @a ct3_get
execute as @a unless score @s ct3_join matches 1 run function cursed_titans:on_join
scoreboard players remove @a[scores={ct3_cd=1..}] ct3_cd 1
execute as @a[scores={ct3_get=1..}] at @s run function cursed_titans:give/select
scoreboard players set @a[scores={ct3_get=1..}] ct3_get 0
execute as @a[scores={ct3_use=1..}] at @s run function cursed_titans:on_click
scoreboard players set @a[scores={ct3_use=1..}] ct3_use 0
# Armor sets: visuals 4x/s, effects 1x/s
scoreboard players add #t ctfx_clock 1
scoreboard players operation #m ctfx_clock = #t ctfx_clock
scoreboard players operation #m ctfx_clock %= #5 ct3_const
execute if score #m ctfx_clock matches 0 run function cursed_titans:auras/visual
execute if score #t ctfx_clock matches 20.. run function cursed_titans:auras/second
execute if score #t ctfx_clock matches 20.. run scoreboard players set #t ctfx_clock 0
