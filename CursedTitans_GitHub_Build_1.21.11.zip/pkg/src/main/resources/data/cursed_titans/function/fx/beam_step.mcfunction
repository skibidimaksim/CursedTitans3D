# context: positioned at the current beam point, rotated along the aim.
execute unless block ~ ~ ~ #cursed_titans:passable run return 0
particle minecraft:flame ~ ~ ~ 0.05 0.05 0.05 0.01 3 force
particle minecraft:end_rod ~ ~ ~ 0 0 0 0.01 1 force
execute as @e[type=#cursed_titans:targets,tag=!ct_caster,tag=!ct_hit,distance=..2.2] run function cursed_titans:fx/solar_hit
scoreboard players remove #steps ct3_tmp 1
execute if score #steps ct3_tmp matches 1.. positioned ^ ^ ^1 run function cursed_titans:fx/beam_step
