execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{ct_id:"titan_phone"}] run dialog show @s cursed_titans:main
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{ct_id:"warden_blade"}] run function cursed_titans:abilities/warden_blade
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{ct_id:"void_blade"}] run function cursed_titans:abilities/void_blade
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{ct_id:"solar_blade"}] run function cursed_titans:abilities/solar_blade
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{ct_id:"warden_axe"}] run function cursed_titans:abilities/warden_axe
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{ct_id:"void_axe"}] run function cursed_titans:abilities/void_axe
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{ct_id:"solar_axe"}] run function cursed_titans:abilities/solar_axe
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{ct_id:"warden_staff"}] run function cursed_titans:abilities/warden_staff
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{ct_id:"void_staff"}] run function cursed_titans:abilities/void_staff
execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_data~{ct_id:"solar_staff"}] run function cursed_titans:abilities/solar_staff
