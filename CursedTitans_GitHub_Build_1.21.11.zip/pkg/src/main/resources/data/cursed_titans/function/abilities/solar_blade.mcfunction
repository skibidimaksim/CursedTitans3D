execute if score @s ct3_cd matches 1.. run return run function cursed_titans:cooldown_msg
tag @s add ct_caster
playsound minecraft:entity.blaze.shoot master @a[distance=..24] ~ ~ ~ 1 1
playsound minecraft:item.firecharge.use master @a[distance=..24] ~ ~ ~ 1 1.2
scoreboard players set #steps ct3_tmp 10
execute anchored eyes positioned ^ ^ ^0.5 run function cursed_titans:fx/beam_step
tag @e[tag=ct_hit] remove ct_hit
effect give @s minecraft:fire_resistance 8 0 true
tag @s remove ct_caster
title @s actionbar [{"text":"✦ ","color":"gold"},{"translate":"ct.ability.solar_blade","fallback":"Solar Flash","color":"gold"}]
scoreboard players set @s ct3_cd 120
