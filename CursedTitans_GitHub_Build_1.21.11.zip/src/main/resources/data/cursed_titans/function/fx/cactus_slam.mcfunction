damage @s 7 minecraft:thorns by @p[tag=ct_caster]
effect give @s minecraft:slowness 3 2
effect give @s minecraft:weakness 4 0
