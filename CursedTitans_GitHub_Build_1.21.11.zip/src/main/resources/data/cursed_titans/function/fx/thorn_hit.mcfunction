damage @s 8 minecraft:thorns by @p[tag=ct_caster]
effect give @s minecraft:slowness 4 1
effect give @s minecraft:poison 3 0
