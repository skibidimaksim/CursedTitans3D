give @s cursed_titans:cactus_helmet 1
give @s cursed_titans:cactus_chestplate 1
give @s cursed_titans:cactus_leggings 1
give @s cursed_titans:cactus_boots 1
title @s actionbar {"translate":"ct.got_armor","fallback":"Set received: %s","with":[{"translate":"ct.set.cactus.name","fallback":"Emerald Cactus Titan"}],"color":"dark_green"}
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 0.55 1.2
