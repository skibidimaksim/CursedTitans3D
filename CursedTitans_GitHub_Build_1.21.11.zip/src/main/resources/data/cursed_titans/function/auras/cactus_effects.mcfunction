effect give @s minecraft:resistance 3 0 true
tag @s add ct_caster
execute as @e[type=#cursed_titans:targets,tag=!ct_caster,distance=..3] run damage @s 2 minecraft:thorns by @p[tag=ct_caster]
tag @s remove ct_caster
