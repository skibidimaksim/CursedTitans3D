execute as @a[tag=ct_set_cactus] at @s run function cursed_titans:auras/cactus_effects
execute as @a[tag=ct_set_void] at @s run function cursed_titans:auras/void_effects
execute as @a[tag=ct_set_solar] at @s run function cursed_titans:auras/solar_effects
