# Re-evaluate which full sets each player wears, then draw halos.
tag @a remove ct_set_cactus
execute as @a if items entity @s armor.head cursed_titans:cactus_helmet if items entity @s armor.chest cursed_titans:cactus_chestplate if items entity @s armor.legs cursed_titans:cactus_leggings if items entity @s armor.feet cursed_titans:cactus_boots run tag @s add ct_set_cactus
tag @a remove ct_set_void
execute as @a if items entity @s armor.head cursed_titans:void_helmet if items entity @s armor.chest cursed_titans:void_chestplate if items entity @s armor.legs cursed_titans:void_leggings if items entity @s armor.feet cursed_titans:void_boots run tag @s add ct_set_void
tag @a remove ct_set_solar
execute as @a if items entity @s armor.head cursed_titans:solar_helmet if items entity @s armor.chest cursed_titans:solar_chestplate if items entity @s armor.legs cursed_titans:solar_leggings if items entity @s armor.feet cursed_titans:solar_boots run tag @s add ct_set_solar
execute as @a[tag=ct_set_cactus] at @s run function cursed_titans:auras/cactus_particles
execute as @a[tag=ct_set_void] at @s run function cursed_titans:auras/void_particles
execute as @a[tag=ct_set_solar] at @s run function cursed_titans:auras/solar_particles
