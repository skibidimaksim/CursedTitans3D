execute if score @s ct3_cd matches 1.. run return run function cursed_titans:cooldown_msg
tag @s add ct_caster
playsound minecraft:block.rooted_dirt.break master @a[distance=..24] ~ ~ ~ 1 1
playsound minecraft:entity.generic.explode master @a[distance=..24] ~ ~ ~ 0.7 0.8
particle minecraft:composter ~ ~0.3 ~ 2.5 0.3 2.5 0.09 90 force
particle minecraft:happy_villager ~ ~1 ~ 2 0.6 2 0.1 40 force
effect give @s minecraft:strength 6 0 true
effect give @s minecraft:resistance 6 1 true
execute as @e[type=#cursed_titans:targets,tag=!ct_caster,distance=..4.5] run function cursed_titans:fx/cactus_slam
tag @s remove ct_caster
title @s actionbar [{"text":"✦ ","color":"dark_green"},{"translate":"ct.ability.cactus_axe","fallback":"Stone Fortress","color":"dark_green"}]
scoreboard players set @s ct3_cd 180
