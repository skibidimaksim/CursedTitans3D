execute if score @s ct3_cd matches 1.. run return run function cursed_titans:cooldown_msg
tag @s add ct_caster
playsound minecraft:block.amethyst_block.chime master @a[distance=..20] ~ ~ ~ 0.95 0.7
playsound minecraft:entity.player.attack.sweep master @a[distance=..20] ~ ~ ~ 1 0.6
particle minecraft:sweep_attack ^ ^1 ^1.5 0.4 0.2 0.4 0 3 force
particle minecraft:composter ^ ^1 ^2.5 0.8 0.4 0.8 0.02 30 force
particle minecraft:happy_villager ^ ^1 ^4 1.2 0.5 1.2 0.07 30 force
effect give @s minecraft:resistance 4 0 true
execute positioned ^ ^1 ^3 as @e[type=#cursed_titans:targets,tag=!ct_caster,distance=..3.5] run function cursed_titans:fx/thorn_hit
tag @s remove ct_caster
title @s actionbar [{"text":"✦ ","color":"dark_green"},{"translate":"ct.ability.thorn_scythe","fallback":"Thorn Wave","color":"dark_green"}]
scoreboard players set @s ct3_cd 100
