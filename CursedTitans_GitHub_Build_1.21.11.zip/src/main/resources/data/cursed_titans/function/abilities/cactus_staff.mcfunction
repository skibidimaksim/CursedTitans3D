execute if score @s ct3_cd matches 1.. run return run function cursed_titans:cooldown_msg
tag @s add ct_caster
playsound minecraft:block.amethyst_block.chime master @a[distance=..24] ~ ~ ~ 1 1
particle minecraft:happy_villager ~ ~1 ~ 1.6 0.8 1.6 0.10 80 force
particle minecraft:composter ~ ~0.2 ~ 2.5 0.2 2.5 0.03 60 force
effect give @a[distance=..6] minecraft:regeneration 6 1
effect give @a[distance=..6] minecraft:absorption 10 0
execute as @e[type=#cursed_titans:targets,tag=!ct_caster,distance=..6] run effect give @s minecraft:slowness 3 1
tag @s remove ct_caster
title @s actionbar [{"text":"✦ ","color":"dark_green"},{"translate":"ct.ability.cactus_staff","fallback":"Flower of Life","color":"dark_green"}]
scoreboard players set @s ct3_cd 160
