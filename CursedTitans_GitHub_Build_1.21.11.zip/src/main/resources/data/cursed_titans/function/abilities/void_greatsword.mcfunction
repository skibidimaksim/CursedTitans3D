execute if score @s ct3_cd matches 1.. run return run function cursed_titans:cooldown_msg
tag @s add ct_caster
playsound minecraft:entity.enderman.teleport master @a[distance=..24] ~ ~ ~ 1 0.75
particle minecraft:reverse_portal ~ ~1 ~ 0.4 0.8 0.4 0.08 60 force
scoreboard players set #steps ct3_tmp 6
scoreboard players set #dmg ct3_tmp 1
execute rotated ~ 0 run function cursed_titans:fx/dash_step
tag @e[tag=ct_hit] remove ct_hit
execute at @s run particle minecraft:reverse_portal ~ ~1 ~ 0.4 0.8 0.4 0.08 60 force
execute at @s run playsound minecraft:entity.enderman.teleport master @a[distance=..24] ~ ~ ~ 1 1.2
effect give @s minecraft:resistance 3 1 true
tag @s remove ct_caster
title @s actionbar [{"text":"✦ ","color":"light_purple"},{"translate":"ct.ability.void_greatsword","fallback":"Void Rift","color":"light_purple"}]
scoreboard players set @s ct3_cd 140
