package com.cursedstudios.cursedtitans;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import com.geckolib.animatable.GeoItem;
import com.geckolib.animatable.instance.AnimatableInstanceCache;
import com.geckolib.animatable.manager.AnimatableManager;
import com.geckolib.animatable.client.GeoRenderProvider;
import com.geckolib.renderer.GeoArmorRenderer;
import com.geckolib.util.GeckoLibUtil;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Wearable GeoArmorRenderer model (GeckoLib5), not merely a custom inventory icon. */
public final class TitanArmorItem extends Item implements GeoItem {
    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);

    public TitanArmorItem(ArmorMaterial material, ArmorType armorType, Properties properties) {
        super(properties.humanoidArmor(material, armorType));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return this.geoCache; }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        // Static wearable geometry; per-bone animations can be added after game tests.
    }

    @Override
    public void createGeoRenderer(Consumer<GeoRenderProvider> consumer) {
        consumer.accept(new GeoRenderProvider() {
            // Keep one renderer instance per item, avoiding a new renderer every frame.
            private final Supplier<GeoArmorRenderer<?, ?>> renderer = new Supplier<>() {
                private GeoArmorRenderer<?, ?> cached;
                @Override public GeoArmorRenderer<?, ?> get() {
                    if (cached == null) cached = new GeoArmorRenderer<>(TitanArmorItem.this);
                    return cached;
                }
            };
            @Override
            public GeoArmorRenderer<?, ?> getGeoArmorRenderer(ItemStack stack, EquipmentSlot slot) {
                return this.renderer.get();
            }
        });
    }
}
